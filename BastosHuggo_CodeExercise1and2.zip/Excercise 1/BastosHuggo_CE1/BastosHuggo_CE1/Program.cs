﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BastosHuggo_CE1
{
    class Program
    {
        static void Main(string[] args)
        {
            // Array, variable to loop, and current order
            string[] coffeeBrands = new string[] {"Dunkin Donuts", "Starbucks", "Dunn Bros", "Dutch Bros Coffee", "Franck", "Indian Coffee House", "Kraft Foods", "Keurig Green Mountain", "Lavazza", "Nestle", "Dulce Cafe", "Barcaffe", "Baristas", "Caffe Nero", "Alterra Coffee Roasters", "An Giang Coffee", "Black Ivory Coffee", "Diedrich Coffee", "Delta Cafes", "Jittery Joe's"};
            bool running = true;
            string currentOrder = "Random";

            while (running)
            {
                // User input 
                string userInput;
                int userInputParse;

                // Displaying the menu fresh every time and the current order of the array
                Console.Clear();
                Console.WriteLine("Please choose one of the following: \n1. Display Array \n2. Alphabetize Array (A-Z) \n3. Alphabetize Array (Z-A) \n4. Loop and Delete Array \n5. Exit");
                Console.WriteLine($"\nCurrent Order: {currentOrder}");
                userInput = Console.ReadLine();
                
                // Converting user answer to a number and making sure they pick an actual option
                while(!int.TryParse(userInput, out userInputParse) || (userInputParse < 1 || userInputParse > 5))
                {
                    Console.WriteLine("That is not an option. Please input a number 1-5.");
                    userInput = Console.ReadLine();
                }

                // Switch statement to handle the cases
                switch (userInputParse)
                { 
                    // Display current order of the array
                    case 1:
                        Console.WriteLine($"\nOrder: {currentOrder}");
                        DisplayArray(coffeeBrands);
                        break;
                    // Sorting the array A-Z w/ array.sort
                    case 2:
                        currentOrder = "A-Z";
                        Console.WriteLine($"\nOrder: {currentOrder}");
                        Array.Sort(coffeeBrands);
                        DisplayArray(coffeeBrands);
                        break;
                    // Sorting the array then reversing it to get Z-A
                    case 3:
                        currentOrder = "Z-A";
                        Console.WriteLine($"\nOrder: {currentOrder}");
                        Array.Sort(coffeeBrands);
                        Array.Reverse(coffeeBrands);
                        DisplayArray(coffeeBrands);
                        break;
                    // Running the function to 
                    case 4:
                        LoopAndDelete(coffeeBrands);
                        break;
                    // Running the loop function
                    case 5:
                        running = false;
                        break;
                }
                Console.ReadKey();
            }          
        }

        // Displaying array method
        static public void DisplayArray(string[] coffeeArray)
        {
            foreach(string s in coffeeArray)
            {
                Console.Write($"{s}, ");
            }
        }

        // Looping and deleting array method
        static public void LoopAndDelete(string[] coffeeArray)
        {
            // Turning the array into a list so we can remove at an index
            List<string> coffeeList = new List<string>(coffeeArray);

            // While there are still values in the array
            while (coffeeList.Count > 0)
            {
                // Display the whole current list of strings
                foreach (string s in coffeeList)
                {
                    Console.Write($"{s}, ");
                }

                Console.WriteLine("\n");
                // Getting a random number and removing that index
                Random random = new Random();
                int randomNum = random.Next(0, coffeeList.Count);
                coffeeList.RemoveAt(randomNum);
            }
        }
    }
}
