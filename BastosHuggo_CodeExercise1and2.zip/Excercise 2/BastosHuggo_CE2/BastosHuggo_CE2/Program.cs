﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BastosHuggo_CE2
{
    class Program
    {
        static void Main(string[] args)
        {
            // Displaying user the info for the game
            Console.Clear();
            Console.WriteLine("Today we are going to be playing a game. I will give you a set of clues and you " +
                "must determine what place I am describing. I will let you know up fron it is a place that makes coffee." +
                "The answer is also just one word. I will give you a total of 5 clues at most.");

            // Running until user gets the right answer and looping with i
            bool running = true;
            string userAnswer = "";
            int i = 0;

            // Loop
            while (running)
            {
                // Switch for the clues, increment i for the next clue
                switch (i)
                {
                    case 0:
                        i++;
                        Console.WriteLine("\nClue #1 \nThis place sells donuts and coffee.");
                        break;
                    case 1:
                        i++;
                        Console.WriteLine("\nClue #2 \nWe have all different flavors you can put in your coffee, including caramel or mocha.");
                        break;
                    case 2:
                        i++;
                        Console.WriteLine("\nClue #3 \nThe name of this coffee shop is two words but it is often reffered to by just the first word.");
                        break;
                    case 3:
                        i++;
                        Console.WriteLine("\nClue #4 \nYou don't dip your donut in your coffee but instead you ________ it.");
                        break;
                    case 4:
                        i++;
                        Console.WriteLine("\nClue #5 \nThis is your last clue. America runs on _________!");
                        break;
                    case 5:
                        Console.WriteLine("\nThere are no more clues.");
                        break;
                }

                // Take user input and if it is correct set 'running' to false to break the loop.
                userAnswer = Console.ReadLine();
                if(userAnswer == "Dunkin")
                {
                    Console.WriteLine("\nCongrats! Next time I'll make it a little harder, some of those hints may have given it away.");
                    running = false;
                }
            }
        }
    }
}
