﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BastosHuggo_CE4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Clear();

            // Array of the colors
            List<string> colors = new List<string> { "Red", "Orange", "Yellow", "Green", "Blue", "Indigo", "Violet" };

            // Asking user to select a color and having a bool to see if they entered it.
            Console.WriteLine("What is your favorite color?");
            bool favoriteColor = false;

            // As long as there is a single element in the array
            while (colors.Count >= 1)
            {
                // Setting i to 0
                int i = 0;

                // If they have already selected a favorite color.
                if(favoriteColor == true)
                {
                    Console.WriteLine("Please choose a color to learn a fact about from below.");
                }

                // Displaying all of the colors the user can choose
                while (i < colors.Count)
                {
                    Console.WriteLine(i + 1 + $". {colors[i]}");
                    i++;
                }

                //  Asking for user input with a case for each color
                string input = Console.ReadLine();
                switch (input.ToLower().Trim())
                {
                    case "red":
                        Console.WriteLine("\nThis color is often associated with anger.\n");
                        colors.Remove("Red");
                        break;
                    case "orange":
                        Console.WriteLine("\nIn the Elizabethan Era only nobility was allowed to wear orange.\n");
                        colors.Remove("Orange");
                        break;
                    case "yellow":
                        Console.WriteLine("\nIn almost all cultures, yellow represents sunshine, warmth, and happiness.\n");
                        colors.Remove("Yellow");
                        break;
                    case "green":
                        Console.WriteLine("\nGreen is the color used in night vision goggles because the human eye is most sensitive and able to distinguish shades in that color.\n");
                        colors.Remove("Green");
                        break;
                    case "blue":
                        Console.WriteLine("\nOwls are the only bird that can pick up the color blue.");
                        Console.WriteLine("Bonus Fun Fact!: This is actually the favorite color of the user that created this program.\n");
                        colors.Remove("Blue");
                        break;
                    case "indigo":
                        Console.WriteLine("\nIndigo is a dye made from the indigo plant and is used to dye denim clothes and make blue jeans.\n");
                        colors.Remove("Indigo");
                        break;
                    case "violet":
                        Console.WriteLine("\nPurple often represents/is known as the color of relaxation. It is often favored by designers, artists, and musicians for also helping stimulate creativity.\n");
                        colors.Remove("Violet");
                        break;
                    // Default case if the user doesn't select a valid option
                    default:
                        Console.WriteLine("\nThat is not a valid option.\n");
                        break;
                }
                favoriteColor = true;
            }
            // End of Code
            Console.WriteLine("Bonus Fact! The colors above is the order of the colors in the rainbow. Have a great day!\n");
        }
    }
}
