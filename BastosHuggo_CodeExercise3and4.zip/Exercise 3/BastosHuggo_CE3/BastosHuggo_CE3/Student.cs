﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BastosHuggo_CE3
{
    class Student
    {
        // Variables for each student
        string firstName;
        string lastName;
        string class1;
        string class2;
        string class3;
        string class4;
        string class5;
        double class1Grade;
        double class2Grade;
        double class3Grade;
        double class4Grade;
        double class5Grade;

        // Default Constructor, used for before they have selected a student
        public Student()
        {
        }

        // Student Constructor, an array for the classes makes the coding quicker because all students will have the same 5 classes
        public Student(string first, string last, string[] classes, double c1grade, double c2grade, double c3grade, double c4grade, double c5grade)
        {
            firstName = first;
            lastName = last;
            class1 = classes[0];
            class2 = classes[1];
            class3 = classes[2];
            class4 = classes[3];
            class5 = classes[4];
            class1Grade = c1grade;
            class2Grade = c2grade;
            class3Grade = c3grade;
            class4Grade = c4grade;
            class5Grade = c5grade;
        }

        // Property for first and last name to display selected student
        public string FirstName
        {
            get { return firstName; }
            set { firstName = value; }
        }

        public string LastName
        {
            get { return lastName; }
            set { lastName = value; }
        }

        public double Class1Grade
        {
            get { return class1Grade; }
            set { class1Grade = value; }
        }

        public double Class2Grade
        {
            get { return class2Grade; }
            set { class2Grade = value; }
        }

        public double Class3Grade
        {
            get { return class3Grade; }
            set { class3Grade = value; }
        }

        public double Class4Grade
        {
            get { return class4Grade; }
            set { class4Grade = value; }
        }

        public double Class5Grade
        {
            get { return class5Grade; }
            set { class5Grade = value; }
        }
        // Method to display student
        public void DisplayStudentInfo()
        {
            Console.WriteLine("\nStudent: " + firstName + " " + lastName);
            Console.WriteLine("Class #1: " + class1 + " Current Grade: " + class1Grade);
            Console.WriteLine("Class #2: " + class2 + " Current Grade: " + class2Grade);
            Console.WriteLine("Class #3: " + class3 + " Current Grade: " + class3Grade);
            Console.WriteLine("Class #4: " + class4 + " Current Grade: " + class4Grade);
            Console.WriteLine("Class #5: " + class5 + " Current Grade: " + class5Grade);

            double gpa = (class1Grade + class2Grade + class3Grade + class4Grade + class5Grade) / 5;
            char gpaLetter = ' ';

            if (gpa >= 89.5 && gpa < 100)
            {
                gpaLetter = 'A';
            }
            else if (gpa < 89.5 && gpa >= 79.5)
            {
                gpaLetter = 'B';
            }
            else if (gpa < 79.5 && gpa >= 72.5)
            {
                gpaLetter = 'C';
            }
            else if (gpa < 72.5 && gpa >= 69.5)
            {
                gpaLetter = 'D';
            }
            else if (gpa < 69.5 && gpa >= 0)
            {
                gpaLetter = 'F';
            }
            Console.WriteLine($"Total GPA: {gpaLetter}. Exect Grade: {gpa} \nPress a key to continue");
            Console.ReadKey();
        }

        public void EditStudent(string[] classesAvailable)
        {
            Console.WriteLine("\nWhich class would you like to edit from this student.");
            foreach (string s in classesAvailable)
            {
                Console.WriteLine($"{s}");
            }
            Console.WriteLine("Exit");
            string input = Console.ReadLine();
            double newGrade = 0;

            bool realClass = false;
            while (realClass == false)
            {
                switch (input.ToLower().Trim())
                {
                    case "coffee 101":
                        newGrade = getDouble(0, 100, "\nPlease Enter in a number between 0-100");
                        class1Grade = newGrade;
                        realClass = true;
                        break;
                    case "the perfect cup":
                        newGrade = getDouble(0, 100, "\nPlease Enter in a number between 0-100");
                        class2Grade = newGrade;
                        realClass = true;
                        break;
                    case "coffee's effect on the mind":
                        newGrade = getDouble(0, 100, "\nPlease Enter in a number between 0-100");
                        class3Grade = newGrade;
                        realClass = true;
                        break;
                    case "how coffee changed the world":
                        newGrade = getDouble(0, 100, "\nPlease Enter in a number between 0-100");
                        class4Grade = newGrade;
                        realClass = true;
                        break;
                    case "the evolution of coffee":
                        newGrade = getDouble(0, 100, "\nPlease Enter in a number between 0-100");
                        class5Grade = newGrade;
                        realClass = true;
                        break;
                    case "exit":
                        realClass = true;
                        break;
                    default:
                        Console.WriteLine("That was not a valid selection, please choose again");
                        input = Console.ReadLine();
                        break;
                }
            }

        }

        public double GetGrade(int classNumber)
        {
            double grade = 0;
            if (classNumber == 0)
            {
                grade = Class1Grade;
            }
            else if (classNumber == 1)
            {
                grade = Class2Grade;
            }
            else if (classNumber == 2)
            {
                grade = Class3Grade;
            }
            else if (classNumber == 3)
            {
                grade = Class4Grade;
            }
            else if (classNumber == 4)
            {
                grade = Class5Grade;
            }

            return grade;
        }

        public double getDouble(int min, int max, string message)
        {
            string input;
            double newGrade = 0;

            Console.WriteLine(message);
            input = Console.ReadLine();

            while (!double.TryParse(input, out newGrade) || (newGrade < 0 || newGrade > 100))
            {
                Console.WriteLine(message);
                input = Console.ReadLine();
            }

            return newGrade;
        }
    }
}
