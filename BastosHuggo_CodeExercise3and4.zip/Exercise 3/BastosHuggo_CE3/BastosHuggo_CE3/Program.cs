﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BastosHuggo_CE3
{
    class Program
    {
        static void Main(string[] args)
        {
            // Varaible to loop until user exits program and default student until the user selects a student
            bool running = true;
            Student current = new Student();

            // Classes
            string[] classes = new string[] {"Coffee 101", "The Perfect Cup", "Coffee's Effects on the Mind", "How Coffee Changed the World", "The Evolution of Coffee" };

            // This is made above the loop so that way any changes made are not reverted
            Student student1 = new Student("Huggo", "Bastos", classes, 97.00D, 95.00D, 92.00D, 97.00D, 96.00D);
            Student student2 = new Student("Hannah", "Johnson", classes, 95.00D, 88.00D, 87.00D, 88.00D, 87.00D);
            Student student3 = new Student("Venanzio", "Paparelli", classes, 87.00D, 88.00D, 89.00D, 84.00D, 94.00D);
            Student student4 = new Student("Taylor", "Youngsma", classes, 80.00D, 76.00D, 83.00D, 79.00D, 81.00D);
            Student student5 = new Student("Chandapaul", "Hamilton", classes, 92.00D, 91.00D, 84.00D, 92.00D, 91.00D);
            Student[] students = new Student[] { student1, student2, student3, student4, student5};

            // Program runs until user exits
            while (running)
            {
                // Clear the console and display the menu each time
                Console.Clear();
                Console.WriteLine("Choose one of the following options (Type out your answer for this program i.e. review gpa). \nReview Students \nReview GPA \nEdit Student \nExit");
                Console.WriteLine($"Current Student: {current.FirstName + " " + current.LastName}");
                string input = Console.ReadLine();

                // Switch statement for different cases of user input
                switch (input.ToLower().Trim())
                {
                    // Having the user pick a student
                    case "review students":
                        Console.WriteLine("\nPlease select a student from below by typing their first name.");
                        foreach(Student s in students)
                        {
                            Console.WriteLine($"{s.FirstName + " " + s.LastName}");
                        }
                        Console.WriteLine("Exit");
                        input = Console.ReadLine();
                        bool realStudent = false;
                        while (realStudent == false)
                        {
                            switch (input.ToLower().Trim())
                            {
                                case "huggo":
                                    current = student1;
                                    realStudent = true;
                                    break;
                                case "hannah":
                                    current = student2;
                                    realStudent = true;
                                    break;
                                case "venanzio":
                                    current = student3;
                                    realStudent = true;
                                    break;
                                case "taylor":
                                    current = student4;
                                    realStudent = true;
                                    break;
                                case "chandapaul":
                                    current = student5;
                                    realStudent = true;
                                    break;
                                case "exit":
                                    realStudent = true;
                                    break;
                                default:
                                    Console.WriteLine("That was not a valid selection, please choose again");
                                    input = Console.ReadLine();
                                    break;
                            }
                        }
                        break;

                    // Having the user pick a gpa to show
                    case "review gpa":
                        if (current.FirstName == null)
                        {
                            Console.WriteLine("You must select a student first. \nPress a key to continue");
                            Console.ReadKey();
                        }
                        else
                        {
                            Console.WriteLine("\nWould you like to review the gpa for this student or a class. \nStudent \nClass");
                            input = Console.ReadLine();

                            // Switch statement for different cases of user input
                            switch (input.ToLower().Trim())
                            {
                                case "student":
                                    current.DisplayStudentInfo();
                                    break;
                                case "class":
                                    DisplayClasses(classes, students);
                                    break;
                            }
                        }
                        break;
                    case "edit student":
                        if (current.FirstName == null)
                        {
                            Console.WriteLine("\nYou must select a student first. \nPress a key to continue");
                            Console.ReadKey();
                        }
                        else
                        {
                            current.EditStudent(classes);
                        }
                        break;
                    case "exit":
                        running = false;
                        break;
                }

            }
        }

        // Method to display and choose a class
        public static void DisplayClasses(string[] allClasses, Student[] students)
        {
            Console.WriteLine("\nPlease select a class from below to see all grades for.");
            foreach (string s in allClasses)
            {
                Console.WriteLine($"{s}");
            }
            Console.WriteLine("Exit");
            string input = Console.ReadLine();
            int classNumber = -1;

            bool realClass = false;
            while (realClass == false)
            {
                switch (input.ToLower().Trim())
                {                   
                    case "coffee 101":
                        classNumber = 0;
                        realClass = true;
                        break;
                    case "the perfect cup":
                        classNumber = 1;
                        realClass = true;
                        break;
                    case "coffee's effect on the mind":
                        classNumber = 2;
                        realClass = true;
                        break;
                    case "how coffee changed the world":
                        classNumber = 3;
                        realClass = true;
                        break;
                    case "the evolution of coffee":
                        classNumber = 4;
                        realClass = true;
                        break;
                    case "exit":
                        realClass = true;
                        break;
                    default:
                        Console.WriteLine("That was not a valid selection, please choose again");
                        input = Console.ReadLine();
                        break;
                }
            }
            double currentGrade = 0;
            double classGPA = 0;

            Console.WriteLine($"\n{allClasses[classNumber]}");
            foreach (Student s in students)
            {
                currentGrade = s.GetGrade(classNumber);
                Console.WriteLine(s.FirstName + " " + s.LastName + $" Grade: {currentGrade}");
                classGPA += currentGrade;
            }
            char gpaLetter = ' ';
            classGPA = classGPA / 5;

            if (classGPA >= 89.5 && classGPA < 100)
            {
                gpaLetter = 'A';
            }
            else if (classGPA < 89.5 && classGPA >= 79.5)
            {
                gpaLetter = 'B';
            }
            else if (classGPA < 79.5 && classGPA >= 72.5)
            {
                gpaLetter = 'C';
            }
            else if (classGPA < 72.5 && classGPA >= 69.5)
            {
                gpaLetter = 'D';
            }
            else if (classGPA < 69.5 && classGPA >= 0)
            {
                gpaLetter = 'F';
            }

            Console.WriteLine($"Class GPA : {gpaLetter} Class # Grade Average: {classGPA}");
            Console.ReadKey();
        }
    }
}
