﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BastosHuggo_CE7
{
    class Program
    {
        static void Main(string[] args)
        {
            // Running unless the user chooses no 
            bool running = true;
            while (running)
            {
                // Clearing and telling the user we are creating a story
                Console.Clear();
                Console.WriteLine("A Day at the Zoo! \nToday we are going to be creating a story. Would you like to help (yes/no)");

                // User answers
                string[] userAnswers = new string[12];

                // Switch statement with user response
                string askForHelp = Console.ReadLine();
                switch (askForHelp.ToLower().Trim())
                {
                    case "yes":
                        // Explaining the game.
                        Console.WriteLine("I will ask for nouns, verbs, adjectives, and adverbs. If you do not know what any of thses are refer to the descriptions below." +
                            "\nExample Sentence: The brown fox quickly ran up the tree." +
                            "\nNoun: A person, place, or thing. In the example sentence the fox and the tree would both be examples of nouns." +
                            "\nAdjective: Describes a noun. In the example sentence the word brown would be an example of an adjective." +
                            "\nVerb: An action performed. In the example sentence the word run would be an example of a verb." +
                            "\nAdverb: Describes and adjective or a verb. In the example sentence the word quickly would be an adverb. They commonly, but not always, and en \"ly\".");

                        // Asking for user responses
                        Console.Write("\nGive me an adjective: ");
                        userAnswers[0] = Console.ReadLine();
                        Console.Write("Give me a noun: ");
                        userAnswers[1] = Console.ReadLine();
                        Console.Write("Give me a verb (past tense). An example for run would be ran or for cook would be cooked: ");
                        userAnswers[2] = Console.ReadLine();
                        Console.Write("Give me an adverb: ");
                        userAnswers[3] = Console.ReadLine();
                        Console.Write("Give me an adjective: ");
                        userAnswers[4] = Console.ReadLine();
                        Console.Write("Give me an noun: ");
                        userAnswers[5] = Console.ReadLine();
                        Console.Write("Give me an noun: ");
                        userAnswers[6] = Console.ReadLine();
                        Console.Write("Give me an adjective: ");
                        userAnswers[7] = Console.ReadLine();
                        Console.Write("Give me an verb: ");
                        userAnswers[8] = Console.ReadLine();
                        Console.Write("Give me an adverb: ");
                        userAnswers[9] = Console.ReadLine();
                        Console.Write("Give me an verb (past tense): ");
                        userAnswers[10] = Console.ReadLine();
                        Console.Write("Give me an adjective: ");
                        userAnswers[11] = Console.ReadLine();

                        // Displaying the story
                        Console.WriteLine($"\nToday I went to the zoo. I saw a {userAnswers[0]} {userAnswers[1]} jumping up and down in its tree. He {userAnswers[2]} {userAnswers[3]} " +
                            $"through the large tunnel that led to its {userAnswers[4]} {userAnswers[5]}. I got some peanuts and passed them through the cage to a gigantic " +
                            $"gray {userAnswers[6]} towering above my head. Feeding that animal made me hungry. I went to get a {userAnswers[7]} scoop of ice cream. It filled my stomach. " +
                            $"Afterwards I had to {userAnswers[8]} {userAnswers[9]} to catch our bus. When I got home I {userAnswers[10]} my mom for a {userAnswers[11]} day at the zoo. \n\nPress any key to exit the program.");
                        Console.ReadKey();
                        running = false;
                        break;
                    case "no":
                        Console.WriteLine("\nGoodbye!");
                        running = false;
                        break;
                    // If the user does not choose one of the options
                    default:
                        Console.WriteLine("That is not one of the options. Press any key to continue.");
                        Console.ReadKey();
                        break;
                }
            }
        }
    }
}
