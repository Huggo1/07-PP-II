﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BastosHuggo_CE6
{
    class Player
    {
        // Name 
        string name;

        // Points
        int totalPoints;

        // Place
        string place;

        // Plaoyer cards
        List<string> cards;

        // Name property
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        // Points property
        public int TotalPoints
        {
            get { return totalPoints; }
            set { totalPoints = value; }
        }

        // Name property
        public string Place
        {
            get { return place; }
            set { place = value; }
        }

        // Cards property
        public List<string> Cards
        {
            get { return cards; }
            set { cards = value; }
        }

        // Creating a new player
        public Player(string n, List<string> playerCards)
        {
            name = n;
            cards = playerCards;
        }

        // Trimming the code in main for creating players
        public Player CreatePlayer(int playerNum)
        {
            List<string> cards = new List<string> { };
            Console.WriteLine($"Please enter in a name for player #{playerNum}.");
            string name = Console.ReadLine();
            Player newPlayer = new Player(name, cards);

            return newPlayer;
        }

        public void AssignCards(Player p1, Player p2, Player p3, Player p4)
        {
            // Because I am going in order of distributing cards for each 13 cards player one will always get a 4th card while others get 3.
            // I am using this to determine if we skip the player that round. Player 1 will be skipped on the second dealing, then player 2, then player 3.
            // This ensure all players will end with the same amount of cards
            string skip = "";

            // Used for the loop
            int i = 0;
            while (i < 4)
            {
                List<string> cards = new List<string> { "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A" };
                // After the first round we will skip this card
                if (i == 1)
                {
                    skip = "skip1";
                }
                else if (i == 2)
                {
                    skip = "skip2";
                }
                else if (i == 3)
                {
                    skip = "skip3";
                }

                // Using this to loop through the list
                while (cards.Count() > 0)
                {
                    // For the random card
                    Random random = new Random();

                    // Player 1; Get random card, add card to player, remove card from available cards
                    if (cards.Count() > 0)
                    {
                        // This handles if we skip or not. If we skip on skip1 we will change skip so we don't do it again 
                        if (skip == "skip1" || skip == "skip2" || skip == "skip3")
                        {
                            if (skip == "skip1")
                            {
                                skip = "";
                            }
                        }
                        else
                        {
                            int randomCard = random.Next(0, cards.Count());
                            p1.Cards.Add(cards[randomCard]);
                            cards.RemoveAt(randomCard);
                        }
                    }

                    // Player 2; Get random card, add card to player, remove card from available cards
                    if (cards.Count() > 0)
                    {
                        if (skip == "skip2" || skip == "skip3")
                        {
                            if (skip == "skip2")
                            {
                                skip = "";
                            }
                        }
                        else
                        {
                            int randomCard = random.Next(0, cards.Count());
                            p2.Cards.Add(cards[randomCard]);
                            cards.RemoveAt(randomCard);
                        }
                    }

                    // Player 3; Get random card, add card to player, remove card from available cards
                    if (cards.Count() > 0)
                    {
                        if (skip == "skip3")
                        {
                            if (skip == "skip3")
                            {
                                skip = "";
                            }
                        }
                        else
                        {
                            int randomCard = random.Next(0, cards.Count());
                            p3.Cards.Add(cards[randomCard]);
                            cards.RemoveAt(randomCard);
                        }
                    }
                    // Player 4; Get random card, add card to player, remove card from available cards
                    if (cards.Count() > 0)
                    {
                        int randomCard = random.Next(0, cards.Count());
                        p4.Cards.Add(cards[randomCard]);
                        cards.RemoveAt(randomCard);
                    }
                }
                i++;
            }
        }

        public int TotalPointsCalc()
        {
            int totalPoints = 0;
            foreach (string s in cards)
            {
                if (s == "2")
                {
                    totalPoints += 2;
                }
                if (s == "3")
                {
                    totalPoints += 3;
                }
                if (s == "4")
                {
                    totalPoints += 4;
                }
                if (s == "5")
                {
                    totalPoints += 5;
                }
                if (s == "6")
                {
                    totalPoints += 6;
                }
                if (s == "7")
                {
                    totalPoints += 7;
                }
                if (s == "8")
                {
                    totalPoints += 8;
                }
                if (s == "9")
                {
                    totalPoints += 9;
                }
                if (s == "10")
                {
                    totalPoints += 10;
                }
                if (s == "J")
                {
                    totalPoints += 12;
                }
                if (s == "Q")
                {
                    totalPoints += 12;
                }
                if (s == "K")
                {
                    totalPoints += 12;
                }
                if (s == "A")
                {
                    totalPoints += 15;
                }
            }
            return totalPoints;
        }

        public void DisplayCards()
        {
            int totalScore;
            Console.WriteLine($"\n{name}'s cards is as follows: ");
            cards.ForEach(Console.WriteLine);
            totalScore = TotalPointsCalc();
            Console.WriteLine($"{name}'s total points are: {totalScore}");
        }
    }
}
