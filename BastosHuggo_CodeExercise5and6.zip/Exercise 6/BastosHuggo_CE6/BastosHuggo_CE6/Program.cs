﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BastosHuggo_CE6
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Clear();
            List<string> s = new List<string> { };
            // Deck of Cards
            Player blankPlayer = new Player("", s);

            // While running
            bool running = true;
            while (running)
            {
                // Creating players 1-4
                Console.WriteLine("Today we will be handing out cards randomly to 4 different players and determining a winner based off of points.");
                Player player1 = blankPlayer.CreatePlayer(1);
                Player player2 = blankPlayer.CreatePlayer(2);
                Player player3 = blankPlayer.CreatePlayer(3);
                Player player4 = blankPlayer.CreatePlayer(4);

                player1.AssignCards(player1, player2, player3, player4);
                player1.DisplayCards();
                player2.DisplayCards();
                player3.DisplayCards();
                player4.DisplayCards();

                int totalDeckScore = player1.TotalPointsCalc();
                totalDeckScore += player2.TotalPointsCalc();
                totalDeckScore += player3.TotalPointsCalc();
                totalDeckScore += player4.TotalPointsCalc();
                Console.WriteLine($"\nTotal Deck Points: {totalDeckScore}");
                running = false;
            }
        }
    }
}
