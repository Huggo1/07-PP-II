﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BastosHuggo_CE5
{
    class Program
    {
        static void Main(string[] args)
        {
            // After the 10 plays if the user says no we will set running to false
            bool running = true;
            while (running)
            {
                // Wins and losses 
                int wins = 0;
                int losses = 0;
                int ties = 0;
                // Clearing the console each time and telling the user we are playing the game 
                Console.Clear();
                Console.WriteLine("Today we are going to be playing rock, paper, sciccors, lizard, Spock.");

                // Until we play 10 times 
                int i = 0;
                while (i < 10)
                {
                    // Outcome
                    string outcome = "";

                    // Getting the number from the user and a random number for the computer between 1-5
                    int userChoice = getInt(1, 5, "Please pick a number between 1 and 5. \n1. Rock \n2. Paper \n3. Scissors \n4. Lizard \n5. Spock");
                    Random random = new Random();
                    int computerChoice = random.Next(0, 5);
                    outcome = calculateOutcome(userChoice, computerChoice);
                    
                    if(outcome == "w")
                    {
                        wins += 1;
                    }
                    else if (outcome == "l")
                    {
                        losses += 1;
                    }
                    else
                    {
                        ties += 1;
                    }
                    i++;
                    Console.WriteLine($"\nYou have played {i} time(s). Your overall score is {wins} win(s), {losses} loss(es), and {ties} tie(s).\n");
                }

                bool play = true;
                while (play)
                {
                    Console.WriteLine("Would you like to play again and re-record all answers. y/n");
                    string playAgain = Console.ReadLine();

                    switch (playAgain.ToLower().Trim())
                    {
                        case "y":
                            play = false;
                            break;
                        case "n":
                            play = false;
                            running = false;
                            break;
                    }
                }
            }
        }

        public static string calculateOutcome(int userChoice, int computerChoice)
        {
            string outcome = "";

            // Case for user selecting Rock
            if(userChoice == 1)
            {
                // Lose to paper and Spock
                if(computerChoice == 2 || computerChoice == 5)
                {
                    Console.WriteLine("You lost!");
                    outcome = "l";
                }
                // Beat Scissors and Lizard
                else if(computerChoice == 3 || computerChoice == 4)
                {
                    Console.WriteLine("Congrats! You won!");
                    outcome = "w";
                }
                // Tie
                else
                {
                    Console.WriteLine("Tie! You both selected the same option.");
                }
            }

            // Case for user selecting Paper
            else if (userChoice == 2)
            {
                // Lost to scissors and lizard
                if (computerChoice == 3 || computerChoice == 4)
                {
                    Console.WriteLine("You lost!");
                    outcome = "l";
                }
                // Beat rock and Spock
                else if (computerChoice == 1 || computerChoice == 5)
                {
                    Console.WriteLine("Congrats! You won!");
                    outcome = "w";
                }
                // Tie
                else
                {
                    Console.WriteLine("Tie! You both selected the same option.");
                }
            }

            // Case for user selecting Scissors
            else if (userChoice == 3)
            {
                // Lose to rock and Spock
                if (computerChoice == 1 || computerChoice == 5)
                {
                    Console.WriteLine("You lost!");
                    outcome = "l";
                }
                // Beat paper and lizard
                else if (computerChoice == 2 || computerChoice == 4)
                {
                    Console.WriteLine("Congrats! You won!");
                    outcome = "w";
                }
                // Tie
                else
                {
                    Console.WriteLine("Tie! You both selected the same option.");
                }
            }

            // Case for user selecting lizard
            else if (userChoice == 4)
            {
                // Lose to rock and scissors
                if (computerChoice == 1 || computerChoice == 3)
                {
                    Console.WriteLine("You lost!");
                    outcome = "l";
                }
                // Beat paper and Spock
                else if (computerChoice == 2 || computerChoice == 5)
                {
                    Console.WriteLine("Congrats! You won!");
                    outcome = "w";
                }
                // Tie 
                else
                {
                    Console.WriteLine("Tie! You both selected the same option.");
                }
            }

            // Case for user selecting Spock
            else if (userChoice == 4)
            {
                // Lose to paper and lizard
                if (computerChoice == 2 || computerChoice == 4)
                {
                    Console.WriteLine("You lost!");
                    outcome = "l";
                }
                // Beat rock and scissors
                else if (computerChoice == 1 || computerChoice == 3)
                {
                    Console.WriteLine("Congrats! You won!");
                    outcome = "w";
                }
                // Tie 
                else
                {
                    Console.WriteLine("Tie! You both selected the same option.");
                }
            }

            return outcome;
        }

        // Method for getting  number from the user
        public static int getInt(int min, int max, string message)
        {
            string input;
            int newGrade = 0;

            Console.WriteLine(message);
            input = Console.ReadLine();

            while (!int.TryParse(input, out newGrade) || (newGrade < min || newGrade > max))
            {
                Console.WriteLine(message);
                input = Console.ReadLine();
            }

            return newGrade;
        }
    }
}

